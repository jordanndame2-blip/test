const baseRender=window.render;
function checkMark(x,y,k=1){ctx.strokeStyle='#147e61';ctx.lineWidth=9;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+20*k,y+20*k);ctx.lineTo(x+60*k,y-25*k);ctx.stroke()}
function motionCard(t,kind,start,end){
 const oral=kind==='oral',speaking=kind==='speaking',dark=oral;
 ctx.fillStyle=dark?'#142560':'#f5f7ff';ctx.fillRect(0,0,1080,1920);
 const g=ctx.createRadialGradient(1000,500,0,800,700,1100);g.addColorStop(0,dark?'#5143e9':'#e1e9ff');g.addColorStop(1,dark?'#13235a':'#f5f7ff');ctx.fillStyle=g;ctx.fillRect(0,0,1080,1920);
 const ink=dark?'#fff':'#15264d',muted=dark?'#c5cffb':'#536480';
 brand(!dark);line('TON ENTRAÎNEMENT, À TON RYTHME',76,234,27,muted,500);
 const tabNames=['LIRE','ÉCOUTER','S’EXPRIMER'];
 const active=speaking?2:oral?1:0;
 tabNames.forEach((txt,i)=>{round(76+i*313,300,294,65,32,i===active?(dark?'#a7ffda':'#2745f3'):(dark?'#ffffff12':'#e6ebf6'));line(txt,102+i*313,343,27,i===active?(dark?'#12264f':'white'):muted);});
 const p=ease((t-start)/.48);
 ctx.save();ctx.translate(0,28*(1-p));ctx.globalAlpha=p;
 line(speaking?'Expression':'Compréhension',76,500,speaking?100:92,ink);
 line(speaking?'orale.':oral?'orale.':'écrite.',76,612,112,ink);
 if(!speaking){
  const y=865;
  line('PLUS DE',84,735,30,muted);
  ctx.save();const scale=.92+.08*ease((t-start)/.7);ctx.translate(76,790);ctx.scale(scale,scale);line('50',0,235,300,dark?'#a3ffd7':'#2944ee');ctx.restore();
  line('séries pour',460,y,69,ink);line('t’entraîner',460,y+90,69,ink);
  round(76,1110,928,340,38,dark?'#ffffff12':'#fff');
  if(oral){
   const mid=1260;
   for(let i=0;i<25;i++){const h=22+95*Math.abs(Math.sin(i*.61+t*3))*Math.sin((i+1)/26*Math.PI);round(120+i*34,mid-h/2,15,h,7,'#a3ffd7')}
   line('Écoute. Comprends. Entraîne-toi.',120,1390,42,'#fff',500);
  }else{
   ctx.strokeStyle='#2944ee';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(165,1160);ctx.lineTo(405,1160);ctx.quadraticCurveTo(445,1160,460,1190);ctx.quadraticCurveTo(480,1160,520,1160);ctx.lineTo(760,1160);ctx.lineTo(760,1310);ctx.lineTo(520,1310);ctx.quadraticCurveTo(480,1310,460,1340);ctx.quadraticCurveTo(445,1310,405,1310);ctx.lineTo(165,1310);ctx.closePath();ctx.stroke();
   ctx.beginPath();ctx.moveTo(460,1190);ctx.lineTo(460,1340);ctx.stroke();
   for(let j=0;j<3;j++){round(205,1195+j*32,190,6,3,'#b9c7ff');round(525,1195+j*32,190,6,3,'#b9c7ff')}
   line('Lis. Comprends. Entraîne-toi.',120,1410,42,'#2944ee',500);
  }
 }else{
  line('Une multitude',76,825,100,'#2944ee');line('de sujets',76,940,115,'#2944ee');
  round(76,1050,928,335,38,'#fff');
  for(let i=0;i<3;i++){round(115+i*270,1100+Math.sin(t*2+i)*9,240,115,21,['#edf2ff','#e5edff','#dff9ec'][i]);line(['PRATIQUER','S’EXPRIMER','PROGRESSER'][i],135+i*270,1168+Math.sin(t*2+i)*9,22,'#293f7e');}
  round(115,1260,850,83,30,'#c8f8df');checkMark(143,1305,.63);line('AVEC CORRECTION',216,1316,46,'#147e61');
  line('Entraîne-toi sans te ruiner.',80,1495,48,ink,500);
 }
 ctx.restore();
 const cap=captions.find(c=>t>=c[0]&&t<c[1]);round(60,1570,960,140,22,dark?'#090f3988':'#e6ebfa');
 if(cap){let y=1625;for(const txt of cap[2].split('\n')){text(txt,90,y,fit(txt,37,900),ink,500);y+=53}}
 round(60,1730,960,117,22,dark?'#0c2254':'#dce6ff');line('APPELS • WHATSAPP • RÉSERVATIONS',89,1767,28,dark?'#b7ffda':'#243bb2');line('690 48 15 07  /  694 03 35 39',89,1820,48,ink);
 line('Objectif de préparation, résultat non garanti.',76,1880,25,muted,400);
 round(76,1908,928,4,2,dark?'#ffffff22':'#d9e0f1');round(76,1908,928*t/45,4,2,dark?'#a3ffd7':'#2944ee');
}
window.render=function(t){
 if(t>=6.941&&t<9.503)motionCard(t,'written',6.941,9.503);
 else if(t>=9.503&&t<12.049)motionCard(t,'oral',9.503,12.049);
 else if(t>=12.049&&t<16.279)motionCard(t,'speaking',12.049,16.279);
 else baseRender(t);
};
hero.onload=()=>render(0);render(0);
