const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d');
const flyer=new Image();flyer.src='flyer.png';
const scenes=[{"a": 0, "b": 3.875}, {"a": 3.875, "b": 16.279}, {"a": 16.279, "b": 21.206}, {"a": 21.206, "b": 23.249}, {"a": 23.249, "b": 25.39}, {"a": 25.39, "b": 29.339}, {"a": 29.339, "b": 34.506}, {"a": 34.506, "b": 45}];
const captions=[[0, 1.7, "Tu prépares le TCF Canada ?"], [1.79, 3.65, "Vise haut, sans te ruiner !"], [3.875, 5.169, "Avec PrepForFuture,"], [5.169, 6.8, "entraîne-toi à ton rythme :"], [6.941, 9.45, "plus de cinquante séries\nde compréhension écrite,"], [9.503, 12, "plus de cinquante séries\nde compréhension orale,"], [12.049, 15.98, "et une multitude de sujets d’expression orale\ndisponibles avec correction."], [16.279, 17.935, "Pour notre promotion de fin d’année,"], [17.935, 21.1, "profite du pack à seulement\ncinq mille francs CFA par mois :"], [21.206, 23.249, "trente simulations en expression écrite"], [23.249, 25.2, "et quinze examens blancs chaque mois."], [25.39, 26.28, "Entraîne-toi,"], [26.28, 29.18, "apprends de tes erreurs\net avance avec confiance."], [29.339, 31.7, "Objectif : viser quatre C2 !"], [31.965, 34.3, "Inscris-toi sur prepforfuture.com."], [34.506, 36.975, "Pour les appels, WhatsApp et les réservations,"], [36.975, 38.8, "retrouve nos deux numéros à l’écran."], [39, 40.206, "PrepForFuture :"], [40.206, 41.92, "entraîne-toi sans te ruiner !"]];
function text(s,x,y,size=50,color='white',weight=700){ctx.fillStyle=color;ctx.font=`${weight} ${size}px Arial, sans-serif`;ctx.fillText(s,x,y)}
function round(x,y,w,h,r,fill){ctx.fillStyle=fill;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()}
function fit(s,max,width){let n=max;while(n>20){ctx.font=`800 ${n}px Arial`;if(ctx.measureText(s).width<=width)return n;n--}return n}
const hero=new Image();hero.src='hero.png';
function ease(v){v=Math.max(0,Math.min(1,v));return 1-Math.pow(1-v,3)}
function line(s,x,y,size=60,color='#fff',weight=700){ctx.font=`${weight} ${size}px Arial`;ctx.fillStyle=color;ctx.fillText(s,x,y)}
function photo(t,x,y,w,h){if(!hero.complete||!hero.naturalWidth)return;ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();const z=1.04+t*.003;ctx.drawImage(hero,x-w*(z-1)/2,y-h*(z-1)/2,w*z,h*z);ctx.restore()}
function brand(dark=false){round(76,100,62,62,19,dark?'#233cfa':'#fff');ctx.strokeStyle=dark?'#fff':'#2440ee';ctx.lineWidth=3;ctx.beginPath();ctx.arc(107,131,18,0,7);ctx.moveTo(89,131);ctx.lineTo(125,131);ctx.ellipse(107,131,8,18,0,0,7);ctx.stroke();round(127,95,17,17,9,'#75f1bd');line('prepforfuture',156,145,45,dark?'#152455':'#fff');}
function pill(label,x,y,w,light=false){round(x,y,w,60,30,light?'#e7edff':'#ffffff18');line(label,x+26,y+40,25,light?'#243fe7':'#bbffd9');}
function arrow(x,y){ctx.strokeStyle='#122142';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+43,y);ctx.lineTo(x+28,y-16);ctx.moveTo(x+43,y);ctx.lineTo(x+28,y+16);ctx.stroke()}
window.render=function(t){t=Math.min(44.999,Math.max(0,t));let idx=scenes.findIndex(s=>t>=s.a&&t<s.b);const s=scenes[idx];let local=t-s.a;let light=idx===3||idx===4;ctx.clearRect(0,0,1080,1920);ctx.fillStyle=light?'#f5f7ff':'#0b1436';ctx.fillRect(0,0,1080,1920);
 if(idx===0||idx===1||idx===5){photo(t,0,300,1080,1350);const grad=ctx.createLinearGradient(0,300,0,1700);grad.addColorStop(0,'#0b143600');grad.addColorStop(.43,'#0b143600');grad.addColorStop(.8,'#0b1436ed');grad.addColorStop(1,'#0b1436');ctx.fillStyle=grad;ctx.fillRect(0,300,1080,1440);}
 else if(!light){const g=ctx.createRadialGradient(900,700,30,550,800,1150);g.addColorStop(0,'#5933e7');g.addColorStop(.5,'#213aba');g.addColorStop(1,'#0b1436');ctx.fillStyle=g;ctx.fillRect(0,0,1080,1920);ctx.strokeStyle='#ffffff0c';ctx.lineWidth=2;for(let j=0;j<5;j++){ctx.beginPath();ctx.arc(1000,650,280+j*140+t*3,0,7);ctx.stroke()}}
 brand(light);line('TCF CANADA',76,228,24,light?'#677493':'#b1bad5',500);
 const progress=Math.min(1,local/.65);ctx.save();ctx.globalAlpha=ease(progress);ctx.translate(0,38*(1-ease(progress)));
 if(idx===0){pill('VISE HAUT. GARDE TON BUDGET.',76,298,560);line('Prépare ton',76,1095,94);line('TCF Canada.',76,1205,112);line('Entraîne-toi',80,1330,78,'#e3e9ff',500);line('sans te ruiner.',76,1450,102,'#9bffce');}
 if(idx===1){pill('TON OBJECTIF. TON RYTHME.',76,298,490);line('Comprendre.',76,1140,105);line('Pratiquer.',76,1255,110);round(76,1345,928,160,28,'#fffffff0');line('Compréhension écrite et orale',110,1405,43,'#132452');line('Des exercices à ton rythme.',110,1468,42,'#3e4e73',500);}
 if(idx===2){pill('PROMOTION DE FIN D’ANNÉE',76,350,520);line('Investis dans',76,570,82);line('ta préparation.',76,668,90);round(76,790,928,545,40,'#fff');line('LE PACK MENSUEL',120,865,28,'#5c6986');line('5 000',112,1073,230,'#203ee2');line('F CFA / mois',124,1180,73,'#172650');round(120,1240,840,5,2,'#72eabc');line('Ton prochain entraînement',80,1450,53,'#dfe7ff',500);line('commence ici.',80,1515,53,'#dfe7ff',500);}
 if(idx===3||idx===4){let ee=idx===3;pill('INCLUS CHAQUE MOIS',76,350,430,true);line(ee?'Écris.':'Entraîne-toi.',76,590,100,'#111f44');line(ee?'Pratique.':'Prépare-toi.',76,700,100,'#111f44');const n=ee?'30':'15';line(n,65,1070,345,'#2842ea');line(ee?'simulations en':'examens blancs',80,1200,75,'#14244b');if(ee)line('expression écrite',80,1293,75,'#14244b');else line('par mois',80,1293,63,'#52607b',500);round(76,1420,928,120,28,'#e7edff');line('Pack à 5 000 F CFA / mois',114,1496,48,'#233cc1');}
 if(idx===5){pill('CHAQUE ENTRAÎNEMENT COMPTE',76,298,560);line('Entraîne-toi.',76,1170,108);line('Progresse.',76,1292,118,'#9bffce');line('Aborde ton examen avec',80,1410,50,'#e1e8ff',500);line('plus de confiance.',80,1475,50,'#e1e8ff',500);}
 if(idx===6){pill('PROMOTION DE FIN D’ANNÉE',76,335,520);line('Objectif :',76,540,110);line('viser 4 C2.',76,663,106);round(76,760,928,450,40,'#fff');line('5 000 F CFA',117,872,108,'#223ce5');line('/ mois',122,940,48,'#5b6784',500);line('30 simulations en expression écrite',122,1050,42,'#14244b');line('15 examens blancs / mois',122,1130,45,'#14244b');line('INSCRIS-TOI SUR',80,1320,29,'#d8e0ff');round(76,1360,928,132,66,'#9bffce');line('prepforfuture.com',116,1445,67,'#102443');arrow(899,1428);}

 if(idx===7){
  pill('ENTRAÎNE-TOI SANS TE RUINER',76,335,530);
  line('Prêt à te',76,550,108);line('préparer ?',76,670,108);
  line('APPELS, WHATSAPP',80,825,47,'#b9ffdc');
  line('ET RÉSERVATIONS',80,888,47,'#b9ffdc');
  round(76,965,928,170,35,'#ffffff');
  line('690 48 15 07',125,1080,104,'#1836cd');
  round(76,1175,928,170,35,'#ffffff');
  line('694 03 35 39',125,1290,104,'#1836cd');
  line('5 000 F CFA / mois',80,1475,62,'#b9ffdc');
  line('prepforfuture.com',80,1585,69);
 }
 ctx.restore();
 if(idx===7){
  const cap=captions.find(c=>t>=c[0]&&t<c[1]);
  if(cap){round(60,1630,960,120,22,'#070e2eb0');let y=1680;for(const l of cap[2].split('\n')){text(l,90,y,fit(l,36,900),'#fff',500);y+=48}}
 }
 if(idx!==7){
  const cap=captions.find(c=>t>=c[0]&&t<c[1]);
  round(60,1570,960,140,22,light?'#e6ebfa':'#070e2eb0');
  if(cap){let y=1625;for(const l of cap[2].split('\n')){text(l,90,y,fit(l,37,900),light?'#263657':'#fff',500);y+=53}}
  round(60,1730,960,117,22,light?'#dce6ff':'#0c2254');
  line('APPELS • WHATSAPP • RÉSERVATIONS',89,1767,28,light?'#243bb2':'#b7ffda');
  line('690 48 15 07  /  694 03 35 39',89,1820,48,light?'#152657':'#fff');
 }
 line('Objectif de préparation, résultat non garanti.',76,1880,25,light?'#5a6881':'#aebbd8',400);
 if(idx===7)line('Plateforme indépendante de préparation.',76,1805,27,'#aebbd8',400);
 for(let i=0;i<8;i++)round(76+i*117,1908,100,4,2,i<=idx?(light?'#3153ee':'#8cf1c4'):(light?'#d5dcec':'#ffffff22'));

};

hero.onload=()=>render(0);flyer.onload=()=>render(0);render(0);
